module.exports = {
    "extends": "airbnb",
    "rules": {
      "react/jsx-filename-extension": 0,
      "linebreak-style": 0
    }
};