import axios from "axios";

export default {
  // Get the login credentials, etc...
};
