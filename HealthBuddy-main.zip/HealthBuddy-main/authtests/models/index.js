// Exporting an object containing all of our models

module.exports = {
  User: require('./User'),
  Client: require('./Client'),
  Token: require('./Token'),
};
