export { default } from './Prescriptions';
